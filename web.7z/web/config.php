<?php
$con = new mysqli("localhost","root","","travel");
$result = $con->query("SELECT name FROM city ");
    while ($row = $result->fetch_object()){
         $user_arr2[] = $row->name;
     }
     $result->close();
     echo json_encode($user_arr2);
?>