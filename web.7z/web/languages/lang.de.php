<?php
/* 
-----------------
Language: Francais
-----------------
*/

$lang = array();

$lang['PAGE_TITLE'] = 'Meine Webseite Titel';
$lang['HEADER_TITLE'] = 'Meine Website-Header Titel';
$lang['SITE_NAME'] = 'Meine Website';
$lang['SLOGAN'] = 'Mein Slogan hier';
$lang['HEADING'] = 'Position';

// Menu

$lang['MENU_HOME'] = 'Start';
$lang['MENU_ABOUT_US'] = '�ber uns';
$lang['MENU_OUR_PRODUCTS'] = 'Unsere Produkte';
$lang['MENU_CONTACT_US'] = 'Kontaktieren Sie uns';
$lang['MENU_ADVERTISE'] = 'Werben';
$lang['MENU_SITE_MAP'] = 'Site Karte';
?>